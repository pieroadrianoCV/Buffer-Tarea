# BufferManager
Implementación Buffer Manager - Base de Datos II.
