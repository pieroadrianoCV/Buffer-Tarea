#ifndef PLATO_H
#define PLATO_H

#include "Disco.h"

class Plato {
public:
    static void crear_plato(int cant_platos, int cant_pista, int cant_sector);
};

#endif // SCHEMA_MANAGER_H