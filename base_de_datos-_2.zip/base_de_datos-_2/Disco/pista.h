#ifndef PISTA_H
#define PISTA_H

#include "Disco.h"
#include "plato.h"


class Pista{
public:
    static void crear_pista(string superficie_carpeta, int cant_pistas, int cant_sector);
};

#endif 