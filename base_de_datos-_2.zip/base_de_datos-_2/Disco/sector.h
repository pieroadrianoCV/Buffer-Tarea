#ifndef SECTOR_H
#define SECTOR_H

#include "Disco.h"
#include "pista.h"


class Sector{
public:
    static void crear_sector(string pista_carpeta, int cant_sector);
};

#endif 