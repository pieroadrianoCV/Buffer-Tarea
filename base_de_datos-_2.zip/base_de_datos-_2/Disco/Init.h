#ifndef INIT_H
#define INIT_H

#include "Disco.h"
#include "plato.h"
class Init{
public:
    static void init();
};

#endif 