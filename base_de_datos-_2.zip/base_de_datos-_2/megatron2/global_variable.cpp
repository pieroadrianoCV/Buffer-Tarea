#include "global_variable.h"

int id = 0;
