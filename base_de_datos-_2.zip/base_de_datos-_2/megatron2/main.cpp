#include "database.h"
#include <iostream>
using namespace std;

int main() {
    Database::init();
    return 0;
}
