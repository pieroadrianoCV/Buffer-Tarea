#ifndef GLOBALS_H
#define GLOBALS_H

extern int id;

#endif // GLOBALS_H
